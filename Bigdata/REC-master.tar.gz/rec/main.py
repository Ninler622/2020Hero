#!/usr/bin/env python3
#-*-coding:utf-8-*-
# 2020 Summer Practice
# _____________________________________________________________
#     __                                 __                    
#     / |    /                         /    )                  
# ---/__|---/__---------__---__-------/---------__----__----__-
#   /   |  /   ) /   / (_ ` (_ `     /        /   ) /   ) /   )
# _/____|_(___/_(___/_(__)_(__)_____(____/___(___/_/___/_(___/_
#                  /                                        /  
#              (_ /                                     (_ /   
# @version 0.9
# @author Abyss Cong <abyss@safly.org>
# @copyright Copyright (c) OranMe Limited 2020
# @license Confidential - Do not distribute

import os
import re
import json
import requests

base_url = r"http://kunpeng-web.oranme.com/interest/"
item_path = r"/root/Python_Hadoop/itemcf/item.csv"
result_path = r"/root/Python_Hadoop/itemcf/part-00000"

# get api data
api_data = requests.get(base_url+"pull")
api_data = api_data.json()

# loop api data
for user_id in api_data:
	for category_id, books in api_data[user_id].items():
		category_times = 0;
		for book_id, times in books.items():
			category_times += int(times)
		# append to text
		with open(item_path, 'a+') as f:
			f.write(user_id+','+category_id+','+str(category_times)+'\n')

# hadoop
HADOOP_BIN = r"/home/hadoop/hadoop-3.1.3/bin/hadoop"
HADOOP_STREAMING = r"/home/hadoop/hadoop-3.1.3/share/hadoop/tools/lib/hadoop-streaming-3.1.3.jar"
# put hdfs
os.system(HADOOP_BIN+r" fs -put -f /root/Python_Hadoop/itemcf/item.csv /python/itemcf/input")
# remove previous output
os.system(HADOOP_BIN+r" fs -rm -r /python/itemcf/output")
# itemcf
os.system(HADOOP_BIN+r" jar "+HADOOP_STREAMING+" -mapper /root/Python_Hadoop/itemcf/mapper.py -reducer /root/Python_Hadoop/itemcf/reducer.py -input /python/itemcf/input/item.csv -output /python/itemcf/output")
# get result
os.system(HADOOP_BIN+r" fs -get -f /python/itemcf/output/part-00000 /root/Python_Hadoop/itemcf")

# # os._exit()

# submit
def read_input(file):
	with open(file, 'r') as f:
		for i, line in enumerate(f):
			yield line.strip('\r\n')

result = {}
for line in read_input(result_path):
	user, category_id, rating = line.split(',')
	result.setdefault(user, {})
	result[user].setdefault(category_id, rating)

JSON_RESULT = json.dumps(result)

response = requests.post(
	url = base_url+"recommend",
	headers = {'Content-Type': 'application/json'},
	# headers = {'Content-Type': 'text/xml'},
	data = JSON_RESULT,
)
