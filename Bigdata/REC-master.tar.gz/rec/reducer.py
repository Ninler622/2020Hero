#!/usr/bin/env python3
# -*-coding:utf-8 -*

import sys
import math
from operator import itemgetter

def read_input(file):
	for line in file:
		# split the line into words
		yield line.strip()


def reducer(file):
	user_set = set()
	user_category = {}
	total_category = {}
	sim_matrix = {} # related category
	rec_category = {}

	for line in read_input(file):
		user, category, rating = line.split(',')
		user_set.add(user)
		user_category.setdefault(user, {})
		user_category[user].setdefault(category, 0)
		user_category[user][category] += int(rating)
	# prepare total and  relation data
	for user, categories in user_category.items():
		# category total count by user (once per user)
		for category in categories:
			if category not in total_category:
				total_category[category] = 0
			total_category[category] += 1
		# category relation count by user (once per user)
		for cat1 in categories:
			for cat2 in categories:
				if cat1 == cat2:
					continue
				sim_matrix.setdefault(cat1, {})
				sim_matrix[cat1].setdefault(cat2, 0)
				sim_matrix[cat1][cat2] += 1

	# calculate similarity matrix
	for cat1, related_cat2 in sim_matrix.items():
		for cat2, count in related_cat2.items():
			sim_matrix[cat1][cat2] = count / math.sqrt(total_category[cat1] * total_category[cat2])
	# print(sim_matrix)

	# recommend
	for user in user_set:
		for category, rating in user_category[user].items():
			for related_category, sim in sorted(sim_matrix[category].items(), key=itemgetter(1), reverse=True):
				if related_category in user_category[user]:
					continue
				rec_category.setdefault(user, {})
				rec_category[user].setdefault(related_category, 0)
				rec_category[user][related_category] += sim * rating
	# print(rec_category)

	# output
	for user, categories in rec_category.items():
		for category,rating in categories.items():
			print(user+','+category+','+str(rating))

if __name__ == '__main__':
	reducer(sys.stdin)
