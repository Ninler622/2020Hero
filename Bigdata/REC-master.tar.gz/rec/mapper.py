#!/usr/bin/env python3
# -*-coding:utf-8 -*

import sys
import math
from operator import itemgetter

def read_input(file):
    for line in file:
        # split the line into words
        yield line.strip()

def mapper(file):
    for line in read_input(file):
        print(line)

if __name__ == '__main__':
    mapper(sys.stdin)