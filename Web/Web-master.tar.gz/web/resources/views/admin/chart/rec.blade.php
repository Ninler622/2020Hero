<canvas id="rec" width="200" height="200"></canvas>
<script>
$(function () {

    var config = {
        type: 'horizontalBar',
        data: {
            datasets: [{
                label: 'REC.',
                data: [
                    {{ @$recs['Philosophy Religion']?:0 }},
                    {{ @$recs['Sciences']?:0 }},
                    {{ @$recs['Political Science Law']?:0 }},
                    {{ @$recs['Military Science']?:0 }},
                    {{ @$recs['Economy']?:0 }},
                    {{ @$recs['Culture Education and Sports']?:0 }},
                    {{ @$recs['History']?:0 }},
                    {{ @$recs['Medicine Health Care']?:0 }}
                ],
                backgroundColor: [
                    'rgb(142,229,238)',
                    'rgb(154,255,154)',
                    'rgb(102,205,0)',
                    'rgb(139,134,78)',
                    'rgb(205,205,0)',
                    'rgb(238,180,180)',
                    'rgb(238,121,66)',
                    'rgb(255,246,143)'
                ]
            }],
            labels: [
                'Philosophy Religion',
                'Sciences',
                'Political Science Law',
                'Military Science',
                'Economy',
                'Culture Education and Sports',
                'History',
                'Medicine Health Care'
            ]
        },
        options: {
            maintainAspectRatio: false
        }
    };

    var ctx = document.getElementById('rec').getContext('2d');
    new Chart(ctx, config);
});
</script>