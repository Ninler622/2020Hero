<?php

namespace App\Admin\Actions\Buyer;

use Encore\Admin\Actions\BatchAction;
use Illuminate\Database\Eloquent\Collection;

use App\Admin\Controllers\WrapperController as Wrapper;

class BatchOrderAction extends BatchAction
{
	public $name = 'Check out';

	public function handle(Collection $collection)
	{
		$data = [];
		foreach ($collection as $model) {
			$data[] = $model;
		}
		Wrapper::make_order($data);
		return $this->response()->success('Successfully checked out.')->refresh();
	}

}