<?php

namespace App\Admin\Actions\Buyer;

use Encore\Admin\Actions\RowAction;
use Illuminate\Database\Eloquent\Model;

use Log;
use App\Admin\Controllers\WrapperController as Wrapper;

use App\Admin\Models\BookModel;

class AddCartAction extends RowAction
{
	public $name = 'Add to cart';

	public function handle(Model $model)
	{
		// Log::debug($model);

		Wrapper::add_cart($model->id);
		return $this->response()->success('Successfully added to cart.'); //->refresh()
	}

}
