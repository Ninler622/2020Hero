<?php

namespace App\Admin\Actions\Buyer;

use Encore\Admin\Actions\BatchAction;
use Illuminate\Database\Eloquent\Collection;

use App\Admin\Controllers\WrapperController as Wrapper;

class BatchAddCartAction extends BatchAction
{
	public $name = 'Add to cart';

	public function handle(Collection $collection)
	{
		foreach ($collection as $model) {
			Wrapper::add_cart($model->id);
		}

		return $this->response()->success('Successfully added to cart.'); //->refresh()
	}

}