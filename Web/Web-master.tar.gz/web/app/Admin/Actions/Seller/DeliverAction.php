<?php

namespace App\Admin\Actions\Seller;

use Encore\Admin\Actions\RowAction;
use Illuminate\Database\Eloquent\Model;

use Log;
use App\Admin\Controllers\WrapperController as Wrapper;

# https://laravel-admin.org/docs/zh/model-grid-custom-actions

class DeliverAction extends RowAction
{
	public $name = 'Deliver';

	public function handle(Model $model)
	{
		Wrapper::deliver_order($model->id);
		return $this->response()->success('Successfully delivered.')->refresh();
	}

}
