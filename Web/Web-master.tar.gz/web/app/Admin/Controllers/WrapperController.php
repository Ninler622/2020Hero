<?php

namespace App\Admin\Controllers;

use App\Http\Controllers\Controller;

use Encore\Admin\Facades\Admin;
use DB;
use Cache;
use Log;

use App\Admin\Models\BookModel;
use App\Admin\Models\CartModel;
use App\Admin\Models\OrderModel;

class WrapperController extends Controller
{
	public static function pay_order($order_id)
	{
		return OrderModel::where('id', $order_id)->update(['paid' => 1]);
	}

	public static function deliver_order($order_id)
	{
		return OrderModel::where('id', $order_id)->update(['delivered' => 1]);
	}

	public static function make_order(array $carts)
	{		
		foreach ($carts as $cart) {
			$book = self::get_book($cart->book_id);
			//add to order
			$order = new OrderModel;
			$order->user_id  = Admin::user()->id;
			$order->book_id  = $cart->book_id;
			$order->quantity = $cart->quantity;
			$order->price    = $book->price * $cart->quantity;
			$order->save();
			//remove from carts
			CartModel::destroy($cart->id);
			//interest
			self::add_interest($cart->book_id);
		}
		return true;
	}

	public static function get_book($book_id)
	{
		return DB::table('hero_books')->where('id', $book_id)->first();
	}

	public static function show_book($book_id)
	{
		return self::add_interest($book_id);
	}

	public static function add_interest($book_id)
	{
		$user_id = Admin::user()->id;
		$book = self::get_book($book_id);
		if (!$book) {
			return false;
		}
		//redis
		$interest_json = Cache::get($user_id);
		if ($interest_json) {
			$data = json_decode($interest_json, true);
			if (@$data[$book->category_id][$book->id]) {
				$data[$book->category_id][$book->id] += 1;
			}else {
				$data[$book->category_id][$book->id] = 1;
			}
		}else {
			$data = [];
			$data[$book->category_id][$book->id] = 1;
		}
		Cache::forever($user_id, json_encode($data));
		return true;
	}

	public static function get_interest($if_pull = false)
	{
		$opt = 'get';
		if ($if_pull) {
			$opt = 'pull'; //get and remove
		}

		$data = [];
		$users = DB::table('admin_users')->get();
		foreach ($users as $user) {
			$interest_json = Cache::$opt($user->id); //pull/get
			if (!$interest_json) {
				continue;
			}
			$data[$user->id] = json_decode($interest_json, true);
		}
		return $data;
	}

	public static function add_cart($book_id)
	{
		//interest
		self::add_interest($book_id);
		//db
		$data = [
			'user_id' => Admin::user()->id,
			'book_id' => $book_id,
		];
		$foo = DB::table('hero_carts')->where($data)->first();
		if ($foo) {
			DB::table('hero_carts')->where($data)->update([
				'quantity' => $foo->quantity + 1,
			]);
		}else {
			DB::table('hero_carts')->insert($data);
		}
		return true;
	}
}
