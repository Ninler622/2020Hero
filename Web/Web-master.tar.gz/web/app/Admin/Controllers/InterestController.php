<?php

namespace App\Admin\Controllers;

use App\Http\Controllers\Controller;

use DB;
use Log;
use Illuminate\Http\Request;

use App\Admin\Controllers\WrapperController as Wrapper;

use App\Admin\Models\RECModel;

class InterestController extends Controller
{
	public static function get($if_pull = false)
	{
		$data = Wrapper::get_interest($if_pull);
		return json_encode($data);
	}

	public static function pull()
	{
		return self::get(true);
	}

	public static function recommend(Request $request)
	{
		$data = $request->input();
		if ($data) {
			// Log::debug($data);
			RECModel::truncate();
			foreach ($data as $user_id => $recs) {
				foreach ($recs as $category_id => $rating) {
					$rec = new RECModel;
					$rec->user_id = $user_id;
					$rec->category_id = $category_id;
					$rec->rating = $rating;
					$rec->save();
				}
			}
		}
		return $data;
	}
}
