<?php

namespace App\Admin\Controllers\Seller;

use App\Admin\Models\SellerOrderModel;
use Encore\Admin\Controllers\AdminController;
use Encore\Admin\Form;
use Encore\Admin\Grid;
use Encore\Admin\Show;

use Encore\Admin\Facades\Admin;
use DB;

use Illuminate\Support\MessageBag;

use App\Admin\Actions\Seller\DeliverAction;

use App\Admin\Controllers\WrapperController as Wrapper;

class OrderController extends AdminController
{
	/**
	 * Title for current resource.
	 *
	 * @var string
	 */
	protected $title = 'My Order';

	/**
	 * Make a grid builder.
	 *
	 * @return Grid
	 */
	protected function grid()
	{
		$grid = new Grid(new SellerOrderModel);
		//$grid->model()->where('user_id', Admin::user()->id);
		$grid->column('book.picture')->image();
		$grid->column('user.username', 'Buyer');
		$grid->column('book.id', 'No.');
		$grid->column('book.title', 'Title')->limit(20);
		$grid->column('quantity', 'Quantity')->label('info');
		$grid->column('price', 'Total Price')->display(function ($price) {
			return $price . ' USD';
		})->label('info');
		$grid->column('paid', 'Paid')->bool();
		$grid->column('delivered', 'Delivered')->bool();

		$grid->filter(function($filter){
			$filter->disableIdFilter();
			$filter->like('book.id', 'No.');
			$filter->like('book.title', 'Title');
		});

		$grid->disableCreateButton();
		// $grid->disableActions();
		$grid->actions(function ($actions) {
			//$actions->disableDelete();
			$actions->disableEdit();
			$actions->disableView();
			$actions->add(new DeliverAction);
		});
		$grid->disableExport();
		// $grid->disableColumnSelector();

		// $grid->disableRowSelector();
		$grid->batchActions(function ($batch) {
			//$batch->disableDelete();
		});

		return $grid;
	}

	/**
	 * Make a show builder.
	 *
	 * @param mixed $id
	 * @return Show
	 */
	protected function detail($id)
	{
		exit('Not Implemented');
	}

	/**
	 * Make a form builder.
	 *
	 * @return Form
	 */
	protected function form()
	{
		exit('Not Implemented');
	}

}
