<?php

namespace App\Admin\Controllers\Seller;

use App\Admin\Models\SellerBookModel;
use Encore\Admin\Controllers\AdminController;
use Encore\Admin\Form;
use Encore\Admin\Grid;
use Encore\Admin\Show;

use Encore\Admin\Facades\Admin;
use DB;

use Illuminate\Support\MessageBag;

use App\Admin\Controllers\WrapperController as Wrapper;

class StoreController extends AdminController
{
	/**
	 * Title for current resource.
	 *
	 * @var string
	 */
	protected $title = 'My Store';

	/**
	 * Make a grid builder.
	 *
	 * @return Grid
	 */
	protected function grid()
	{
		$grid = new Grid(new SellerBookModel);
		// $grid->model()->orderByRaw('RAND()');
		$grid->column('picture')->image();
		$grid->column('id', 'No.');
		$grid->column('category.name', 'Category')->label();
		$grid->column('title', 'Title')->limit(20);
		$grid->column('author', 'Author')->limit(10);
		$grid->column('date', 'Date');
		$grid->column('press', 'Press');
		$grid->column('price', 'Price')->display(function ($price) {
			return $price . ' USD';
		})->label('info');

		$grid->filter(function($filter){
			$filter->disableIdFilter();
			$filter->like('id', 'No.');
			$filter->like('title', 'Title');
			$filter->like('category.name', 'Category');
		});

		//$grid->disableCreateButton();
		// $grid->disableActions();
		$grid->actions(function ($actions) {
			//$actions->disableDelete();
			//$actions->disableEdit();
			//$actions->disableView();
		});
		//$grid->disableExport();

		$grid->batchActions(function ($batch) {
			//$batch->disableDelete();
		});

		return $grid;
	}

	/**
	 * Make a show builder.
	 *
	 * @param mixed $id
	 * @return Show
	 */
	protected function detail($id)
	{
		Wrapper::view_book($id);

		$show = new Show(SellerBookModel::findOrFail($id));

		$show->picture()->image();
		$show->field('id', 'Book No.');
		$show->field('category.name', 'Category')->label();
		$show->field('title', 'Title');
		$show->field('author', 'Author');
		$show->field('date', 'Date');
		$show->field('press', 'Press');
		$show->field('price', 'Price')->as(function ($price) {
			return $price . ' USD';
		})->label('info');

		$show->panel()
			->tools(function ($tools) {
				//$tools->disableEdit();
				// $tools->disableList();
				//$tools->disableDelete();
		});

		return $show;
	}

	/**
	 * Make a form builder.
	 *
	 * @return Form
	 */
	protected function form()
	{
		$form = new Form(new SellerBookModel);

		//$form->hidden('owner')->value(Admin::user()->id)->rules('required|regex:/^' . Admin::user()->id . '$/');

		$form->text('picture', 'Picture URL');
		$form->text('id', 'Book No.');
		$form->text('category_id', 'Category');
		$form->text('title', 'Title');
		$form->text('author', 'Author');
		$form->text('date', 'Date');
		$form->text('press', 'Press');
		$form->text('price', 'Price');

		$form->tools(function (Form\Tools $tools) {
			//$tools->disableList();
			//$tools->disableDelete();
			$tools->disableView();
		});

		$form->footer(function ($footer) {
			//$footer->disableReset();
			//$footer->disableSubmit();
			$footer->disableViewCheck();
			$footer->disableEditingCheck();
			$footer->disableCreatingCheck();

		});

		return $form;
	}

}
