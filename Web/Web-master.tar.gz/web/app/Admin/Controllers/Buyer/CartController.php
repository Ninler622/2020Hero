<?php

namespace App\Admin\Controllers\Buyer;

use App\Admin\Models\CartModel;
use Encore\Admin\Controllers\AdminController;
use Encore\Admin\Form;
use Encore\Admin\Grid;
use Encore\Admin\Show;

use Encore\Admin\Facades\Admin;
use DB;

use Illuminate\Support\MessageBag;

use App\Admin\Actions\Buyer\OrderAction;
use App\Admin\Actions\Buyer\BatchOrderAction;

use App\Admin\Controllers\WrapperController as Wrapper;

class CartController extends AdminController
{
	/**
	 * Title for current resource.
	 *
	 * @var string
	 */
	protected $title = 'Cart';

	/**
	 * Make a grid builder.
	 *
	 * @return Grid
	 */
	protected function grid()
	{
		$grid = new Grid(new CartModel);
		//$grid->model()->where('user_id', Admin::user()->id);
		$grid->column('book.picture')->image();
		$grid->column('book.id', 'No.');
		$grid->column('book.title', 'Title')->limit(20);
		$grid->column('quantity', 'Quantity')->label('info');
		$grid->column('book.price', 'Unit Price')->display(function ($price) {
			return $price . ' USD';
		})->label('info');

		$grid->filter(function($filter){
			$filter->disableIdFilter();
			$filter->like('book.id', 'No.');
			$filter->like('book.title', 'Title');
		});

		$grid->disableCreateButton();
		// $grid->disableActions();
		$grid->actions(function ($actions) {
			//$actions->disableDelete();
			//$actions->disableEdit();
			$actions->disableView();
			$actions->add(new OrderAction);
		});
		$grid->disableExport();

		$grid->batchActions(function ($batch) {
			//$batch->disableDelete();
			$batch->add(new BatchOrderAction);
		});

		return $grid;
	}

	/**
	 * Make a show builder.
	 *
	 * @param mixed $id
	 * @return Show
	 */
	protected function detail($id)
	{
		exit('Not Implemented');
	}

	/**
	 * Make a form builder.
	 *
	 * @return Form
	 */
	protected function form()
	{
		$form = new Form(new CartModel);

		// $form->display('book.picture');
		$form->display('book.id', 'Book No.');
		$form->display('book.title', 'Title');
		$form->number('quantity', 'Quantity');

		$form->tools(function (Form\Tools $tools) {
			//$tools->disableList();
			//$tools->disableDelete();
			$tools->disableView();
		});

		$form->footer(function ($footer) {
			//$footer->disableReset();
			//$footer->disableSubmit();
			$footer->disableViewCheck();
			$footer->disableEditingCheck();
			$footer->disableCreatingCheck();

		});

		return $form;
	}

}
