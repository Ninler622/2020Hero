<?php

namespace App\Admin\Controllers\Buyer;

use App\Admin\Models\RECModel;
use App\Admin\Models\BookModel;
use Encore\Admin\Controllers\AdminController;
use Encore\Admin\Form;
use Encore\Admin\Grid;
use Encore\Admin\Show;

use Encore\Admin\Facades\Admin;
use DB;

use Illuminate\Support\MessageBag;

use App\Admin\Actions\Buyer\AddCartAction;
use App\Admin\Actions\Buyer\BatchAddCartAction;

use App\Admin\Controllers\WrapperController as Wrapper;

use Encore\Admin\Widgets\Box;

class RECController extends AdminController
{
	/**
	 * Title for current resource.
	 *
	 * @var string
	 */
	protected $title = 'REC.';

	/**
	 * Make a grid builder.
	 *
	 * @return Grid
	 */
	protected function grid()
	{
		$grid = new Grid(new RECModel);

		$grid->header(function ($query) {
			$recs = [];
			$foo = RECModel::where('user_id', Admin::user()->id)
				->join('hero_categories as category', 'category.id', '=', 'hero_recs.category_id')
				->select(
					'category.name as category',
					'rating',
				)
				->get();

			foreach ($foo as $value) {
				$recs[$value->category] = $value['rating'];
			}

			$bar = view('admin.chart.rec', compact('recs'));

			return new Box('You may also like', $bar);
		});

		if (!RECModel::where('user_id', Admin::user()->id)->first()) {
			return redirect('admin/buyer/store');
		}

		$grid->model()->where('user_id', Admin::user()->id);
		$grid->model()
			->join('hero_books as book', 'book.category_id', '=', 'hero_recs.category_id')
			->join('hero_categories as category', 'category.id', '=', 'hero_recs.category_id')
			->select(
				'book.picture',
				'book.id',
				'category.name as category',
				'book.title',
				'book.author',
				'book.date',
				'book.press',
				'book.price',
			)
			->orderByRaw('RAND()');
		// $grid->paginate(5);
		//$grid->disablePagination(); //it will show all data
		$grid->disableFilter();

		$grid->column('picture')->image();
		$grid->column('id', 'No.');
		$grid->column('category', 'Category')->label();
		$grid->column('title', 'Title')->limit(20);
		$grid->column('author', 'Author')->limit(10);
		$grid->column('date', 'Date');
		$grid->column('press', 'Press');
		$grid->column('price', 'Price')->display(function ($price) {
			return $price . ' USD';
		})->label('info');

		$grid->filter(function($filter){
			$filter->disableIdFilter();
			$filter->like('id', 'No.');
			$filter->like('title', 'Title');
			$filter->like('category', 'Category');
		});

		$grid->disableCreateButton();
		// $grid->disableActions();
		$grid->actions(function ($actions) {
			$actions->disableDelete();
			$actions->disableEdit();
			//$actions->disableView();
			$actions->add(new AddCartAction);
		});
		$grid->disableExport();

		$grid->batchActions(function ($batch) {
			$batch->disableDelete();
			$batch->add(new BatchAddCartAction);
		});

		return $grid;
	}

	/**
	 * Make a show builder.
	 *
	 * @param mixed $id
	 * @return Show
	 */
	protected function detail($id)
	{
		Wrapper::show_book($id);

		$show = new Show(RECModel::findOrFail($id));

		$show->picture()->image();
		$show->field('id', 'Book No.');
		$show->field('category.name', 'Category')->label();
		$show->field('title', 'Title');
		$show->field('author', 'Author');
		$show->field('date', 'Date');
		$show->field('press', 'Press');
		$show->field('price', 'Price')->as(function ($price) {
			return $price . ' USD';
		})->label('info');

		$show->panel()
			->tools(function ($tools) {
				$tools->disableEdit();
				// $tools->disableList();
				$tools->disableDelete();
		});

		return $show;
	}

	/**
	 * Make a form builder.
	 *
	 * @return Form
	 */
	protected function form()
	{
		exit('Not Implemented');
	}

}
