<?php

namespace App\Admin\Controllers\Buyer;

use App\Admin\Models\BookModel;
use Encore\Admin\Controllers\AdminController;
use Encore\Admin\Form;
use Encore\Admin\Grid;
use Encore\Admin\Show;

use Encore\Admin\Facades\Admin;
use DB;

use Illuminate\Support\MessageBag;

use App\Admin\Actions\Buyer\AddCartAction;
use App\Admin\Actions\Buyer\BatchAddCartAction;

use App\Admin\Controllers\WrapperController as Wrapper;

class StoreController extends AdminController
{
	/**
	 * Title for current resource.
	 *
	 * @var string
	 */
	protected $title = 'Store';

	/**
	 * Make a grid builder.
	 *
	 * @return Grid
	 */
	protected function grid()
	{
		$grid = new Grid(new BookModel);
		$grid->model()->orderByRaw('RAND()');
		$grid->column('picture')->image();
		$grid->column('id', 'No.');
		$grid->column('category.name', 'Category')->label();
		$grid->column('title', 'Title')->limit(20);
		$grid->column('author', 'Author')->limit(10);
		$grid->column('date', 'Date');
		$grid->column('press', 'Press');
		$grid->column('price', 'Price')->display(function ($price) {
			return $price . ' USD';
		})->label('info');

		$grid->filter(function($filter){
			$filter->disableIdFilter();
			$filter->like('id', 'No.');
			$filter->like('title', 'Title');
			$filter->like('category.name', 'Category');
		});

		$grid->disableCreateButton();
		// $grid->disableActions();
		$grid->actions(function ($actions) {
			$actions->disableDelete();
			$actions->disableEdit();
			//$actions->disableView();
			$actions->add(new AddCartAction);
		});
		$grid->disableExport();

		$grid->batchActions(function ($batch) {
			$batch->disableDelete();
			$batch->add(new BatchAddCartAction);
		});

		return $grid;
	}

	/**
	 * Make a show builder.
	 *
	 * @param mixed $id
	 * @return Show
	 */
	protected function detail($id)
	{
		Wrapper::show_book($id);

		$show = new Show(BookModel::findOrFail($id));

		$show->picture()->image();
		$show->field('id', 'Book No.');
		$show->field('category.name', 'Category')->label();
		$show->field('title', 'Title');
		$show->field('author', 'Author');
		$show->field('date', 'Date');
		$show->field('press', 'Press');
		$show->field('price', 'Price')->as(function ($price) {
			return $price . ' USD';
		})->label('info');

		$show->panel()
			->tools(function ($tools) {
				$tools->disableEdit();
				// $tools->disableList();
				$tools->disableDelete();
		});

		return $show;
	}

	/**
	 * Make a form builder.
	 *
	 * @return Form
	 */
	protected function form()
	{
		exit('Not Implemented');
	}

}
