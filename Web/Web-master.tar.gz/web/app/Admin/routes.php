<?php

use Illuminate\Routing\Router;

Admin::routes();

Route::group([
	'prefix'        => config('admin.route.prefix'),
	'namespace'     => config('admin.route.namespace'),
	'middleware'    => config('admin.route.middleware'),
	'as'            => config('admin.route.prefix') . '.',
], function (Router $router) {

	$router->resources([
		'buyer/rec'   => Buyer\RECController::class,
		'buyer/store' => Buyer\StoreController::class,
		'buyer/cart'  => Buyer\CartController::class,
		'buyer/order' => Buyer\OrderController::class,

		'seller/store' => Seller\StoreController::class,
		'seller/order' => Seller\OrderController::class,

	]);

	$router->get('logs', '\Rap2hpoutre\LaravelLogViewer\LogViewerController@index')->name('logs');
	$router->get('/', 'HomeController@index')->name('home');

});

Route::get('interest/get', '\App\Admin\Controllers\InterestController@get');
Route::get('interest/pull', '\App\Admin\Controllers\InterestController@pull');
Route::any('interest/recommend', '\App\Admin\Controllers\InterestController@recommend');
