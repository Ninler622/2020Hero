<?php
namespace App\Admin\Models;
use Illuminate\Database\Eloquent\Model;

class BookCategoryModel extends Model
{
	protected $table = 'hero_categories';
	public $timestamps = false;
	protected $fillable = [];
}


class BookModel extends Model
{
	protected $table = 'hero_books';
	public $timestamps = true;
	protected $fillable = [];

    public function category()
    {
        return $this->hasOne(BookCategoryModel::class, 'id', 'category_id');
    }
}