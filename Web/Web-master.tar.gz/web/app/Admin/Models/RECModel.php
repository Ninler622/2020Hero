<?php
namespace App\Admin\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletes;

use App\Admin\Models\BookModel;

use Encore\Admin\Facades\Admin;
use Illuminate\Support\Facades\Auth;

class RECModel extends Model
{
	// use SoftDeletes;

	protected $table = 'hero_recs';
	public $timestamps = true;
	protected $fillable = [];

	public static function findOrFail($id)
	{
		return BookModel::findOrFail($id);
	}

}
