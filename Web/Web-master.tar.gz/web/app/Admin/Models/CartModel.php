<?php
namespace App\Admin\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Builder;

use App\Admin\Models\BookModel;

use Encore\Admin\Facades\Admin;


class CartModel extends Model
{
	protected $table = 'hero_carts';
	public $timestamps = false;
	protected $fillable = [];

	protected static function boot()
	{
		parent::boot();
		//limit user_id
		static::addGlobalScope('user_limit', function (Builder $builder) {
			$builder->where('user_id', Admin::user()->id);
		});
	}

	public function book()
	{
		return $this->belongsTo(BookModel::class, 'book_id', 'id');
	}

}
