<?php
namespace App\Admin\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletes;

use Encore\Admin\Facades\Admin;

class SellerBookCategoryModel extends Model
{
	protected $table = 'hero_categories';
	public $timestamps = false;
	protected $fillable = [];
}


class SellerBookModel extends Model
{
	use SoftDeletes;

	protected $table = 'hero_books';
	public $timestamps = true;
	protected $fillable = [];

	protected static function boot()
	{
		parent::boot();
		//limit owner
		static::addGlobalScope('owner_limit', function (Builder $builder) {
			$builder->where('owner', Admin::user()->id);
		});
        //fix form owner
        static::saving(function($model) {
            $model->owner = Admin::user()->id;
        });
	}

    public function category()
    {
        return $this->hasOne(SellerBookCategoryModel::class, 'id', 'category_id');
    }
}