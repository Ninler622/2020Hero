<?php
namespace App\Admin\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletes;

use App\Admin\Models\BookModel;

use Encore\Admin\Facades\Admin;

class OrderModel extends Model
{
	use SoftDeletes;

	protected $table = 'hero_orders';
	public $timestamps = true;
	protected $fillable = [];

	protected static function boot()
	{
		parent::boot();
		//limit user_id
		static::addGlobalScope('user_limit', function (Builder $builder) {
			$builder->where('user_id', Admin::user()->id);
		});
	}

	public function book()
	{
		return $this->belongsTo(BookModel::class, 'book_id', 'id');
	}

}
