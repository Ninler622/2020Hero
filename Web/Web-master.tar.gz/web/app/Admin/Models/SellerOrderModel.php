<?php
namespace App\Admin\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletes;

use App\Admin\Models\BookModel;

use Encore\Admin\Facades\Admin;

class SellerOrderModel extends Model
{
	use SoftDeletes;

	protected $table = 'hero_orders';
	public $timestamps = true;
	protected $fillable = [];

	protected static function boot()
	{
		parent::boot();
		//limit user_id
		static::addGlobalScope('user_limit', function (Builder $builder) {
			$builder->whereRaw("EXISTS(SELECT * FROM `hero_books` where `hero_orders`.`book_id` = `hero_books`.id AND `hero_books`.`owner` = ?)", [Admin::user()->id]);
		});
	}

	public function book()
	{
		return $this->belongsTo(BookModel::class, 'book_id', 'id');
	}

	public function user()
	{
		$userModel = config('admin.database.users_model');
		return $this->belongsTo($userModel, 'user_id', 'id');
	}

}
